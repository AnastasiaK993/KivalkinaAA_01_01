package com.example.kivalkinaaa_01_01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.text.DecimalFormat
class secondActivity : AppCompatActivity() {
    private lateinit var etNumber: EditText
    private lateinit var spinnerFrom: Spinner
    private lateinit var tvResult: TextView
    private lateinit var btnCalculate: Button

    private val units = arrayOf("Байт", "Килобайт")
    private val conversionRates = doubleArrayOf(1.0, 1024.0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        initViews()
        setupSpinner()
        setupCalculateButton()
    }

    private fun initViews() {
        etNumber = findViewById(R.id.etNumber)
        spinnerFrom = findViewById(R.id.spinnerFrom)
        tvResult = findViewById(R.id.tvResult)
        btnCalculate = findViewById(R.id.btnCalculate)
    }

    private fun setupSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFrom.adapter = adapter
    }

    private fun setupCalculateButton() {
        btnCalculate.setOnClickListener {
            calculateConversion()
        }
    }

    private fun calculateConversion() {
        val inputText = etNumber.text.toString()

        if (inputText.isEmpty()) {
            tvResult.text = "Введите число"
            return
        }

        try {
            val number = inputText.toDouble()
            val fromUnit = spinnerFrom.selectedItemPosition
            val bytes = number * conversionRates[fromUnit]

            val df = DecimalFormat("#.####")
            val result = StringBuilder()

            result.append("Результат:\n")
            for (i in units.indices) {
                val convertedValue = bytes / conversionRates[i]
                result.append("${df.format(convertedValue)} ${units[i]}\n")
            }

            tvResult.text = result.toString()

        } catch (e: NumberFormatException) {
            tvResult.text = "Ошибка: введите корректное число"
        }
    }
}
//package com.example.kivalkinaaa_01_01
//
//
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.widget.*
//import java.text.DecimalFormat
//
//class ConverterActivity : AppCompatActivity() {
//
//    private lateinit var etNumber: EditText
//    private lateinit var spinnerFrom: Spinner
//    private lateinit var tvResult: TextView
//    private lateinit var btnCalculate: Button
//
//    private val units = arrayOf("Байт", "Килобайт")
//    private val conversionRates = doubleArrayOf(1.0, 1024.0)
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_second)
//
//        initViews()
//        setupSpinner()
//        setupCalculateButton()
//    }
//
//    private fun initViews() {
//        etNumber = findViewById(R.id.etNumber)
//        spinnerFrom = findViewById(R.id.spinnerFrom)
//        tvResult = findViewById(R.id.tvResult)
//        btnCalculate = findViewById(R.id.btnCalculate)
//    }
//
//    private fun setupSpinner() {
//        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//        spinnerFrom.adapter = adapter
//    }
//
//    private fun setupCalculateButton() {
//        btnCalculate.setOnClickListener {
//            calculateConversion()
//        }
//    }
//
//    private fun calculateConversion() {
//        val inputText = etNumber.text.toString()
//
//        if (inputText.isEmpty()) {
//            tvResult.text = "Введите число"
//            return
//        }
//
//        try {
//            val number = inputText.toDouble()
//            val fromUnit = spinnerFrom.selectedItemPosition
//            val bytes = number * conversionRates[fromUnit]
//
//            val df = DecimalFormat("#.####")
//            val result = StringBuilder()
//
//            result.append("Результат:\n")
//            for (i in units.indices) {
//                val convertedValue = bytes / conversionRates[i]
//                result.append("${df.format(convertedValue)} ${units[i]}\n")
//            }
//
//            tvResult.text = result.toString()
//
//        } catch (e: NumberFormatException) {
//            tvResult.text = "Ошибка: введите корректное число"
//        }
//    }
//}